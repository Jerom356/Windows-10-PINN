The RPi3/RPi3B+ VC firmware files come from https://github.com/raspberrypi/firmware, and correspond to SHA `54d8888d5b8048af9f7765cfd632faff78ac8053`.
